package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for managing games in the gaming room.
 * 
 * This class represents a singleton service for managing games in the gaming room.
 * It provides methods to add games, retrieve games by index, ID, or name, and get the count of active games.
 * The class uses the Iterator pattern to iterate over the list of games.
 */
public class GameService {

    // A list of active games
    private static List<Game> games = new ArrayList<>();

    // Holds the next game identifier
    private long nextGameId = 1;
    
    // Holds the next team identifier
    private static long nextTeamId = 1;
    
    // Holds the next player identifier
    private static long nextPlayerId = 1;
    
    // Singleton instance variable
    private static GameService instance;

    // Private constructor to prevent direct instantiation
    private GameService() {
    }
    
    // Public static method to access the singleton instance
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance; // Returns the singleton instance of GameService
    }

    /**
     * Construct a new game instance or return an existing one.
     * 
     * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {
        // Check if a game with the same name already exists
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getName().equals(name)) {
                // A game with the same name already exists, return the existing game
                return existingGame;
            }
        }

        // If not found, create a new game instance and add it to the list of games
        Game newGame = new Game(nextGameId++, name);
        games.add(newGame);
        
        return newGame;
    }

    /**
     * Returns the game instance at the specified index.
     * <p>
     * This method is package-private and intended for testing purposes.
     * </p>
     * 
     * @param index the index position in the list to return
     * @return the requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified ID.
     * 
     * @param id the unique identifier of the game to search for
     * @return the requested game instance, or null if not found
     */
    public Game getGame(long id) {
        for (Game game : games) {
            if (game.getId() == id) {
                return game;
            }
        }
        return null; // The game with the specified ID was not found
    }

    /**
     * Returns the game instance with the specified name.
     * 
     * @param name the unique name of the game to search for
     * @return the requested game instance, or null if not found
     */
    public Game getGame(String name) {
        for (Game game : games) {
            if (game.getName().equals(name)) {
                return game;
            }
        }
        return null; // The game with the specified name was not found
    }

    /**
     * Returns the number of active games.
     * 
     * @return the number of active games
     */
    public int getGameCount() {
        return games.size();
    }

    /**
     * Returns the ID for the current index of the Teams list, then increments the counter.
     * 
     * @return the ID of the current team index in the Teams list
     */
    public long getNextTeamId() {
        return nextTeamId++;
    }

    /**
     * Returns the ID for the current index of the Players list, then increments the counter.
     * 
     * @return the ID of the current player index in the Players list
     */
    public long getNextPlayerId() {
        return nextPlayerId++;
    }
}
