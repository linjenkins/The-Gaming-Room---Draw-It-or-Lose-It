package com.gamingroom;

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * author coce@snhu.edu
 *
 */
public class Player extends Entity {
    private long id; // Player ID
    private String name; // Player name

    /**
     * Constructor with an identifier and name
     * Creates a Player object with the provided id and name
     *
     * @param id   the ID of the player
     * @param name the name of the player
     */
    public Player(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Returns the ID of the player
     *
     * @return the ID of the player
     */
    public long getId() {
        return id;
    }

    /**
     * Returns the name of the player
     *
     * @return the name of the player
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Player [id=" + id + ", name=" + name + "]";
    }
}
