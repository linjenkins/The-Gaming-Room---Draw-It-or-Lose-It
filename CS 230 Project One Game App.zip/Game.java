package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 *
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 *
 * author coce@snhu.edu
 *
 */
public class Game extends Entity {
    // A list of the active teams
    private static List<Team> teams = new ArrayList<>();

    /**
     * Constructor with an identifier and name
     * Creates a Game object with the provided id and name
     *
     * @param id   the ID of the game
     * @param name the name of the game
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team to the game.
     * If a team with the same name already exists in the game, it returns the existing instance.
     * Otherwise, it creates a new team instance and adds it to the game.
     *
     * @param name the name of the team
     * @return the Team instance (new or existing)
     */
    public Team addTeam(String name) {
        // Check if a team with the same name already exists in the game
        for (Team existingTeam : teams) {
            if (existingTeam.getName().equals(name)) {
                return existingTeam; // Team with the same name already exists, so return the existing instance
            }
        }

        // If not found, create a new team instance and add it to the game
        Team team = new Team(teams.size() + 1, name);
        teams.add(team);
        return team; // return the new/existing team instance to the caller
    }

    @Override
    public String toString() {
        return "Game [id=" + this.getId() + ", name=" + this.getName() + "]";
    }
}
