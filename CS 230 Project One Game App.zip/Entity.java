package com.gamingroom;

/**
 * Creates a base class for Game, Player, and Team to use.
 * Represents an entity with an ID and name.
 */
public class Entity {
    private long id;
    private String name;

    public Entity() {// Default constructor
    }

    /**
     * Creates an Entity object with the specified ID and name.
     *
     * @param id   the ID of the entity
     * @param name the name of the entity
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Returns the ID of the entity.
     *
     * @return the ID of the entity
     */
    public long getId() {
        return id;
    }

    /**
     * Returns the name of the entity.
     *
     * @return the name of the entity
     */
    public String getName() {
        return name;
    }

    /**
     * Returns a string representation of the Entity object.
     *
     * @return a string representation of the Entity object
     */
    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}

