package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * author coce@snhu.edu
 *
 */
public class Team extends Entity {

    // A list of the active teams
    private static List<Player> players = new ArrayList<>();

    /**
     * Constructor with an identifier and name
     * Creates a Team object with the provided id and name
     *
     * @param id   the ID of the team
     * @param name the name of the team
     */
    public Team(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player to the team.
     * If a player with the same name already exists in the team, it returns the existing instance.
     * Otherwise, it creates a new player instance and adds it to the team.
     *
     * @param name the name of the player
     * @return the Player instance (new or existing)
     */
    public Player addPlayer(String name) {
        Player player = null;
        // Iterate through players in the team
        Iterator<Player> playerIterator = players.iterator();
        // Check for duplicate players on the same team
        while (playerIterator.hasNext()) {
            player = playerIterator.next();
            if (player.getName().equals(name)) {
                break;
            }
            player = null;
        }
        // If not found, create a new player instance and add it to the team
        if (player == null) {
            player = new Player(players.size() + 1, name);
            players.add(player);
        }
        return player;
    }

    @Override
    public String toString() {
        return "Team [id=" + this.getId() + ", name=" + this.getName() + "]";
    }
}
