package com.gamingroom.gameauth.controller;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gamingroom.gameauth.representations.GameUserInfo;

@Produces(MediaType.TEXT_PLAIN)
@Path("/client/")
public class RESTClientController {
    private Client client;

    public RESTClientController(Client client) {
        this.client = client;
    }

    @GET
    @Path("/gameusers")
    // Endpoint to retrieve all game users
    public String getGameUsers() {
        // Create a WebTarget pointing to the game users resource
        WebTarget webTarget = client.target("http://localhost:8080/gameusers");
        // Build the request invocation
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        // Send a GET request and retrieve the response
        Response response = invocationBuilder.get();
        // Read the response entity as an ArrayList of GameUserInfo objects
        @SuppressWarnings("rawtypes")
        ArrayList gameusers = response.readEntity(ArrayList.class);
        // Return the string representation of the game users list
        return gameusers.toString();
    }

    @GET
    @Path("/gameusers/{id}")
    // Endpoint to retrieve a specific game user by ID
    public String getGameUserById(@PathParam("id") int id) {
        // Create a WebTarget pointing to the game user resource with the specified ID
        WebTarget webTarget = client.target("http://localhost:8080/gameusers/" + id);
        // Build the request invocation
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
        // Send a GET request and retrieve the response
        Response response = invocationBuilder.get();
        // Read the response entity as a GameUserInfo object
        GameUserInfo gameUserInfo = response.readEntity(GameUserInfo.class);
        // Return the string representation of the game user
        return gameUserInfo.toString();
    }
}
