package com.gamingroom.gameauth.controller;

import io.dropwizard.auth.Auth;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Set;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.gamingroom.gameauth.auth.GameUser;
import com.gamingroom.gameauth.dao.GameUserDB;
import com.gamingroom.gameauth.representations.GameUserInfo;

@Path("/gameusers")
@Produces(MediaType.APPLICATION_JSON)
public class GameUserRESTController {

    private final Validator validator;

    public GameUserRESTController(Validator validator) {
        this.validator = validator;
    }

    @PermitAll
    @GET
    // Endpoint to retrieve all game users
    public Response getGameUsers(@Auth GameUser user) {
        // Return the list of game users
        return Response.ok(GameUserDB.getGameUsers()).build();
    }

    @RolesAllowed("USER")
    @GET
    @Path("/{id}")
    // Endpoint to retrieve a specific game user by ID
    public Response getGameUserById(@PathParam("id") Integer id, @Auth GameUser user) {
        // You can validate here if the user is watching his record
        /*if(id != user.getId()){
            // Not allowed
        }*/

        GameUserInfo gameUserInfo = GameUserDB.getGameUser(id);
        if (gameUserInfo != null) {
            // Return the game user with the specified ID
            return Response.ok(gameUserInfo).build();
        } else {
            // Return a 404 response if the game user is not found
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @RolesAllowed("ADMIN")
    @POST
    // Endpoint to create a new game user
    public Response createGameUser(GameUserInfo gameUserInfo, @Auth GameUser user) throws URISyntaxException {
        // Validation
        Set<ConstraintViolation<GameUserInfo>> violations = validator.validate(gameUserInfo);
        GameUserInfo existingUser = GameUserDB.getGameUser(gameUserInfo.getId());
        if (violations.size() > 0) {
            ArrayList<String> validationMessages = new ArrayList<String>();
            for (ConstraintViolation<GameUserInfo> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }
        if (existingUser != null) {
            // Update the existing game user
            GameUserDB.updateGameUser(gameUserInfo.getId(), gameUserInfo);
            return Response.created(new URI("/gameusers/" + gameUserInfo.getId())).build();
        } else {
            // Return a 404 response if the game user is not found
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @PUT
    @Path("/{id}")
    // Endpoint to update a game user by ID
    public Response updateGameUserById(@PathParam("id") Integer id, GameUserInfo gameUserInfo) {
        // Validation
        Set<ConstraintViolation<GameUserInfo>> violations = validator.validate(gameUserInfo);
        GameUserInfo existingUser = GameUserDB.getGameUser(gameUserInfo.getId());
        if (violations.size() > 0) {
            ArrayList<String> validationMessages = new ArrayList<String>();
            for (ConstraintViolation<GameUserInfo> violation : violations) {
                validationMessages.add(violation.getPropertyPath().toString() + ": " + violation.getMessage());
            }
            return Response.status(Status.BAD_REQUEST).entity(validationMessages).build();
        }
        if (existingUser != null) {
            // Update the game user
            gameUserInfo.setId(id);
            GameUserDB.updateGameUser(id, gameUserInfo);
            return Response.ok(gameUserInfo).build();
        } else {
            // Return a 404 response if the game user is not found
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @DELETE
    @Path("/{id}")
    // Endpoint to remove a game user by ID
    public Response removeGameUserById(@PathParam("id") Integer id) {
        GameUserInfo gameUserInfo = GameUserDB.getGameUser(id);
        if (gameUserInfo != null) {
            // Remove the game user
            GameUserDB.removeGameUser(id);
            return Response.ok().build();
        } else {
            // Return a 404 response if the game user is not found
            return Response.status(Status.NOT_FOUND).build();
        }
    }
}
