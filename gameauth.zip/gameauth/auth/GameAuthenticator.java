package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    // Define a map of valid users with their associated roles
    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "admin", ImmutableSet.of("ADMIN", "USER")
    );

    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {
        // Check if the provided credentials are valid
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) {
            // Create a new instance of GameUser with the authenticated username and roles
            GameUser gameUser = new GameUser(credentials.getUsername(), VALID_USERS.get(credentials.getUsername()));
            // Return the authenticated user as an optional
            return Optional.of(gameUser);
        }
        // If the credentials are not valid, return an empty optional
        return Optional.empty();
    }
}
